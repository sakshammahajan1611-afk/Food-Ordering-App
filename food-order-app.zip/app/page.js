"use client";
import { useState } from "react";

export default function FoodOrderApp() {
  const [cart, setCart] = useState([]);
  const [name, setName] = useState("");
  const [room, setRoom] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");

  const menu = [];

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  const getTotal = () => {
    return cart.reduce((sum, item) => sum + (item.price || 0), 0);
  };

  const placeOrder = () => {
    if (!name) return alert("Enter name");
    if (!room) return alert("Enter room/villa");
    if (cart.length === 0) return alert("Cart empty");

    const orderText = cart
      .map((item) => `${item.name || "Item"} - ₹${item.price || 0}`)
      .join("%0A");

    const message = `Airbnb Order%0AName: ${name}%0ARoom: ${room}%0APhone: ${phone}%0AOrder:%0A${orderText}%0ATotal: ₹${getTotal()}%0ANotes: ${notes}`;

    const restaurantPhone = "91XXXXXXXXXX"; // CHANGE THIS

    window.open(`https://wa.me/${restaurantPhone}?text=${message}`, "_blank");
  };

  return (
    <div style={{ maxWidth: 600, margin: "auto" }}>
      <h1>Mehfil Mitran Di - Room Service</h1>

      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} style={{ width: "100%", marginBottom: 10, padding: 8 }} />
      <input placeholder="Room/Villa" value={room} onChange={e => setRoom(e.target.value)} style={{ width: "100%", marginBottom: 10, padding: 8 }} />
      <input placeholder="Phone (optional)" value={phone} onChange={e => setPhone(e.target.value)} style={{ width: "100%", marginBottom: 10, padding: 8 }} />
      <input placeholder="Notes" value={notes} onChange={e => setNotes(e.target.value)} style={{ width: "100%", marginBottom: 20, padding: 8 }} />

      {menu.length === 0 && <p>Add your menu items in code.</p>}

      <div>
        <h3>Cart</h3>
        {cart.map((item, i) => (
          <p key={i}>{item.name || "Item"} - ₹{item.price || 0}</p>
        ))}
        <b>Total: ₹{getTotal()}</b>
      </div>

      {cart.length > 0 && (
        <button onClick={placeOrder} style={{ marginTop: 20, padding: 10, width: "100%" }}>
          Order on WhatsApp
        </button>
      )}
    </div>
  );
}