export const metadata = {
  title: "Mehfil Mitran Di - Room Service",
  description: "Scan & Order for Airbnb"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
        {children}
      </body>
    </html>
  );
}